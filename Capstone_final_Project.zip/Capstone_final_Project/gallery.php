<!DOCTYPE html>
<?php
session_start();
require ("mysqli_connect.php");

?>
<HTML lang="en">
<head>
<title>Gallery</title>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/style.css">
    	<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    
	<script src="https://code.jquery.com/jquery-3.2.1.js"></script>

    </head>
<body>	<div class="wrapper">
		<div class="header">
			<div class="header_top">
				<div class="container">
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 padding_part">
						<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
							<div class="header_top_left">
                                <img src="images/logo.png" class="img-responsive">
                                
						
					</div>
				</div>
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
							<nav class="navbar">
		    					<div class="navbar-header">
		      						<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
								        <span class="icon-bar"></span>
								        <span class="icon-bar"></span>
								        <span class="icon-bar"></span>
								    </button>
		    					</div>
		    					<ul class="nav navbar-nav">
							        	<li class="active"><a href="index.php">Home</a></li>
							        	
							        	<li class="active"><a href="gallery.php">Collection</a></li>
                                        <li class="active"><a href="aboutus.php">About Us</a></li>
							        	<li class="active"><a href="contact.php">Contact Us</a></li>
                                        <?php
	   									if(!empty($_SESSION["username"])):
										?>
                                        <li class="active"><a href="logout.php">Logout</a></li>
									<li style="color:white " ><i class="fa fa-user fa-2x" title="<?php echo $_SESSION['username'];?>"></i></li>
										<?php else: ?>
										<li class="active"><a href="login.php">Login/Register</a></li>
										<?php endif;?>
							      	</ul>
							</nav>
                              
						</div>
								
							</div>
						</div>
						
			
						
				</div>
			</div><!--header_bottom-->
		</div><!--header-->
		<div class="slider">
					<div class="w3-content w3-section" >
                         <img class="mySlides" src="imagesnew/oia-416136_1920.jpg"   style="width:80%;height:400px;margin:auto;">
                        <img class="mySlides" src="imagesnew/hallstatt-3609863_1920.jpg" style="width:80%;height:400px;margin:auto;">
                        <img  class="mySlides"src="imagesnew/cape-town-181753_1920.jpg" style="width:80%;height:400px;margin:auto;">
                          <img class="mySlides" src="imagesnew/rio-de-janeiro-1963744_1920.jpg" style="width:80%;height:400px;margin:auto;">
                        <img  class="mySlides"src="imagesnew/venice-2451047_1920.jpg"style="width:80%;height:400px;margin:auto;">
						 <script>
                        var mineIndex = 0;
                        slides();// call function
                        

                        function slides() {
                        var i;
                        var a = document.getElementsByClassName("mySlides");
                        for (i = 0; i < a.length; i++) {
                        a[i].style.display = "none";  
                        }
                        mineIndex++;
                        if (mineIndex > a.length) {mineIndex = 1}    
                        a[mineIndex-1].style.display = "block";  
                        setTimeout(slides, 1500); // Change images after every 1.5 seconds
                        }
                    </script>

                  <br><br><br> 
                 	<div class="slider">
			<div class="container">
				<div class="slider_main">
					
					<h1>Explore popular vacation package destinations!!</h1>
			
					<div class="find">
						<h4>FIND YOUR TOUR</h4>
						<form>
							<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 padding_part">
								<div class="col-lg-10 col-md-12 col-sm-12 col-xs-12">
									<div class="form-group">
								     	<label for="From">Trip To:</label><br>
								      	<select class="list">
											<option>Niagara Falls</option>
											<option>Aquarium</option>
											<option>Amusement Park</option>
                                            <option>Mountains</option>
										</select>
								    </div>
								    
								    <div class="form-group">
								     	<label for="Departure">Date:</label><br>
								      	<select class="list">
											<option>17/6/2020</option>
											<option>10/6/2020</option>
											<option>1/8/2020</option>
										</select>
								    </div>
								    
								</div>
								<div class="col-lg-2 col-md-12">
									<div class="search_button">
										<a href="packages.html">Search</a>
									</div>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div><!--slider-->
                        
                        
        <section class="photo">
            <h1> Featured Packages</h1>
            <div class="packages">
            <div class="row">
             <div class= "col-md-4">
                <div class= "feature-box">
                   <div class= "feature-img">
                    <a href="packages.html">
                    <img src="imagesnew/mt-fuji-477832_1920.jpg">
                        <div class="price">
                            <p>$150</p></div></a>
                       <div class="rating">
                        <i class="fa fa-star"></i>
                         <i class="fa fa-star"></i>
                           <i class="fa fa-star"></i>
                         <i class="fa fa-star"></i>
                         <i class="fa fa-star-o"></i>
                       </div>
                   </div>
                   <div class= "packages-detail">
                   <h4>Blue Mountains</h4>
                   <p>Don't miss Blue Mountain Resort, the #1 destination in Ontario's Georgian Bay! Explore the mountain and book your vacation online.Enjoy world-class skiing, golf, spas & dining.</p>
                   <div>
                    <span><i class="fa fa-map-marker"></i>South Western</span></div></div>

                   </div></div>
               <div class= "col-md-4">
                <div class= "feature-box">
                   <div class= "feature-img">
                    <a href="packages.html">
                    <img src="imagesnew/aqua.jpg">
                        <div class="price">
                            <p>$150</p></div></a>
                       <div class="rating">
                        <i class="fa fa-star"></i>
                         <i class="fa fa-star"></i>
                           <i class="fa fa-star"></i>
                         <i class="fa fa-star"></i>
                         <i class="fa fa-star-o"></i>
                       </div>
                   </div>
                   <div class= "packages-detail">
                   <h4>Ripels Aquarium</h4>
                   <p>Immerse yourself in a world of 20000 aquatic animals and discover your own underwater adventure at Ripley's Aquarium of Canada!State of the art facilities with over 10000 exotic sea creatures.  </p>
                   <div>
                    <span><i class="fa fa-map-marker"></i>Ontario</span></div></div>

                   </div></div>
                      <div class= "col-md-4">
                          <div class= "feature-box">
                   <div class= "feature-img">
                    <a href="packages.html">
                    <img src="imagesnew/island.jpg">
                        <div class="price">
                            <p>$180</p></div></a>
                       <div class="rating">
                        <i class="fa fa-star"></i>
                         <i class="fa fa-star"></i>
                           <i class="fa fa-star"></i>
                         <i class="fa fa-star"></i>
                           <i class="fa fa-star-half-o"></i>
                       </div>
                   </div>
                   <div class= "packages-detail">
                   <h4>Centre Island Toronto</h4>
                   <p>The Centreville Amusement Park has more than 30 attractions. It is the best Summer dstination.Families will easily be able to make a day out of Centre Island; allow two hours minimum. </p>
                   <div>
                    <span><i class="fa fa-map-marker"></i>Toronto</span></div></div>

                   </div>
                          
                </div>
                </div>
                </div>
            </section>
            
 
    
        
<!--footer-->
		<div class="footer">
			<div class="container">
				<div class=" col-lg-12 col-md-12 col-sm-12 col-xs-12 padding_part">
					<div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
						<div class="contact_us">
							<h4>Contact Us</h4>
							<div class="contact_us_menu">
								<ul>
                                    <li><i class="fa fa-envelope-open" aria-hidden="true"></i><span>jassmeet.2125@gmail.com</span></li>
									<li><i class="fa fa-mobile" aria-hidden="true"></i><span>123-254-2356</span></li>
									<li><i class="fa fa-map-pin" aria-hidden="true"></i><span>1235,Street Market Canada Ontario. </span></li>
								</ul>
                                <p>© 2020. All rights reserved. </p>
                                
                              
							</div>
						</div>
             
                        	
					</div>
                                 

                </div>
		</div><!--footer-->
                                 
<i class="fa fa-facebook" style="font-size:40px"></i>
<i class="fa fa-instagram" style="font-size:36px"></i>
<i class="fa fa-twitter" style="font-size:48px"></i>
         
	</div><!--wrapper-->
    </div> 
    </div>
    </body>
    </HTML>
