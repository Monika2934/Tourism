<h1>Notifications</h1>

<?php
    
    include("function.php");

    $contactid = $_GET['contactid'];

    $query ="UPDATE `contact` SET `status` = 'read' WHERE `contactid` = $contactid;";
    performQuery($query);

    $query = "SELECT * from `contact` where `contactid` = '$contactid';";
    if(count(fetchAll($query))>0){
        foreach(fetchAll($query) as $i){
            if($i['type']=='comment'){
                echo "Some commented on your post.<br/>".$i['comments'];
            }
        }
    }
    
?><br/>
